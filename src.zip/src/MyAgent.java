import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
import za.ac.wits.snake.DevelopmentAgent;

public class MyAgent extends DevelopmentAgent {

    public static void main(String args[]) {
        MyAgent agent = new MyAgent();
        MyAgent.start(agent, args);
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            String initString = br.readLine();
            String[] temp = initString.split(" ");
            int nSnakes = Integer.parseInt(temp[0]);
            int numObstacles=3;

            while (true) {
                String line = br.readLine();
                if (line.contains("Game Over")) {
                    break;
                }

                String apple1 = line;
                String[] appleCoordinates = line.split(" ");
                int appleX = Integer.parseInt(appleCoordinates[0]);
                int appleY = Integer.parseInt(appleCoordinates[1]);
                //do stuff with apples

                for (int j=0; j<numObstacles; j++) {
                	String obsLine = br.readLine();
                }
                
                int mySnakeNum = Integer.parseInt(br.readLine());
                int myHeadX = -1;
                int myHeadY = -1;
                for (int i = 0; i < nSnakes; i++) {
                    String snakeLine = br.readLine();
                    if (i == mySnakeNum) {
                        //hey! That's me :)
                    	String[] snakeInfo = snakeLine.split(" ");
                    	 boolean isAlive = snakeInfo[0].equals("alive");
                         int snakeLength = Integer.parseInt(snakeInfo[1]);
                         int snakeKills = Integer.parseInt(snakeInfo[2]);
                         int headX = Integer.parseInt(snakeInfo[3]);
                         int headY = Integer.parseInt(snakeInfo[4]);
                         
                         if (i == mySnakeNum) {
                             myHeadX = headX;
                             myHeadY = headY;
                         }
                    }
                    //do stuff with other snakes
                }
                //finished reading, calculate move:
              
                int move = calculateMove(myHeadX, myHeadY, appleX, appleY);
                System.out.println(move);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        
        public int calculateMove(int headX, int headY, int appleX, int appleY) {
        	 if (headX < appleX) {
            return 3; // Move right
        } 
        	 else if (headX > appleX) {
            return 2; // Move left
        }
        	 else {
            // Handle the case where your snake is moving downwards, and the apple is above
            if (headY < appleY) {
                if (headY > 0) {
                    return 0; // Move up if possible
                } else {
                    return 3; // Move right to create a path to go up
                }
            } else if (headY > appleY) {
                return 1; // Move down
            } else {
                // If the apple is at the same position as the snake's head, choose a random move
                return new Random().nextInt(3) + 4; // Randomly choose Left, Straight, or Right
            }
        	 }
    }
}